/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2018-09-04     ZeroFree     first implementation
 */

#include <rtthread.h>

void wlan_autoconnect_init(void);
